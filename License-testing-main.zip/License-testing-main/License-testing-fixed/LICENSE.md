SPDX-License-Identifier: MIT OR Apache-2.0

# LICENSE (Version 1.0)

© [YEAR] [OWNER]. All rights reserved.

## Permissions

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the \"Software\"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

## Conditions

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

## Disclaimers

### MIT License

THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

### Apache License, Version 2.0

Licensed under the Apache License, Version 2.0 (the \"License\"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT
WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the
License for the specific language governing permissions and limitations
under the License.

**Patent Grant (Apache 2.0):** Each Contributor hereby grants You a perpetual,
worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as
stated in this section) patent license to make, have made, use, offer to sell,
sell, import, and otherwise transfer the Work, where \"Work\" is the Contribution.

## Universal Default Protection Clause (AI, High-Risk, Commercial, Any Purpose)

**Applicable to ANY project/platform (GitHub, Replit, Vercel, etc.):**
- Covers low/medium/high-risk uses: AI/ML training/generation, finance, medical, automotive, embedded.
- Copyright holder ([OWNER]) provides NO warranties/representations.
- NO liability for any damages/claims/losses, direct/indirect/special.
- Disputes: Binding arbitration in [YOUR JURISDICTION]; no jury trials/class actions.
- Governed by laws of [YOUR JURISDICTION].

## Contributor Note

Contributions (PRs/forks) are licensed under identical terms. Contributors affirm authority to license.

## Setup (Set as Default Everywhere)

1. Edit placeholders: `[YEAR]` (e.g., 2024), `[OWNER]` (You/Org), `[YOUR JURISDICTION]` (e.g., State/Country).
2. Save as `LICENSE.md` in root.
3. Upload to GitHub/Replit/any — SPDX enables auto-license detection.
4. **Ready!** Permissive grants + max protection. 10/10 universal template for ALL cases.

